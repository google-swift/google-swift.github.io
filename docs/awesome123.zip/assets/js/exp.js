import U, {printName as prt} from './user.js'

const user = new U("abo", 12)
console.log(user)
prt(user)