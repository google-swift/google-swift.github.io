const app = Vue.createApp({
    data() {
        return {
            firstName: 'John',
            lastName: 'Doe',
            email: 'awesome@gmail.com',
            gender: 'male',
            picture: 'https://randomuser.me/api/portraits/men/10.jpg',
        }
    },
    methods: {
        async getUser() {
            const res = await fetch("https://randomuser.me/api")
            const { results } = await res.json()

            console.log(results)

            this.firstName = results[0].name.first
            this.lastName = results[0].name.last
            this.email = results[0].email
            this.gender = results[0].gender
            this.picture = results[0].picture.large
        },

        async fetchData() {
            let  data = {}
            const res = await fetch("https://app.sourcesquarechina.online/songs/xcoderelease", {
                method: 'GET', // *GET, POST, PUT, DELETE, etc.
                mode: 'no-cors', // no-cors, *cors, same-origin
                cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
                credentials: 'same-origin', // include, *same-origin, omit
                headers: {
                  'Content-Type': 'application/json'
                  // 'Content-Type': 'application/x-www-form-urlencoded',
                },
                redirect: 'follow', // manual, *follow, error
                referrerPolicy: 'no-referrer', // no-referrer, *no-referrer-when-downgrade, origin, origin-when-cross-origin, same-origin, strict-origin, strict-origin-when-cross-origin, unsafe-url
                // body: JSON.stringify(data) // body data type must match "Content-Type" header
              });
            // const { results } = await res.json()

            console.log("jjjj 7777" + res.json)

        },

        async fet() {
            const data = { username: 'example' };

            fetch('https://app.sourcesquarechina.online/songs/xcoderelease', {
            method: 'GET', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
            //   body: JSON.stringify(data),
            })
            .then(response => response.json())
            .then(data => {
            console.log('Success:', data[0]);
            })
            .catch((error) => {
            console.error('Error:', error);
            });
        },
        async todo(){
            const data = { "title": 'goawesome.com.cn.google.awesome' };

            fetch('https://app.sourcesquarechina.online/songs', {
            method: 'POST', // or 'PUT'
            headers: {
                'Content-Type': 'application/json',
            },
              body: JSON.stringify(data),
            })
            .then(response => response.json())
            .then(data => {
            console.log('Success:', data);
            })
            .catch((error) => {
            // console.error('Error:', error);
            });
        }
    },
    mounted: function(){
        this.$nextTick(function(){
            console.log("everything ready....")
            this.getUser()
            // this.todo()
        })
    }
})

app.mount('#about')

// const app2 = Vue.createApp({

//     data() {
//         return {
//             firstName: 'John',
//             lastName: 'Doe',
//             email: 'awesome@gmail.com',
//             gender: 'male',
//             picture: 'https://randomuser.me/api/portraits/men/10.jpg',
//         }
//     }
// })
// app2.mount('#about')
