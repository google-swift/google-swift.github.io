export default class User {
    constructor(name, age) {
        this.name = name
        this.age = age
    }
}

export function printName(u) {
    console.log(`the name is :${u.name}`)
}

export function printAge() {
    console.log(`the name is :${this.age} old age`)
}